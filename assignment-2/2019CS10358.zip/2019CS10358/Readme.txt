Himanshu Gaurav Singh
2019CS10358

The design is as instructed in the assignment problem statement. The application can be run as follows:

1. Use the command 'python3 server.py' to initiate the server.
2. As many clients as needed can then use 'python3 client.py' to initiate the client process. After this, Type in <username><white-spae><ip address of the server> to begin registration.
3. Sending and receiving protocol are as mentioned in the problem statement.

